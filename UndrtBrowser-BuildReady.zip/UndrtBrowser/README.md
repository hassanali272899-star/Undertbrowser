# Undrt Browser

A standalone Android browser prototype using Android WebView.

Features:
- Separate app identity and local browser data
- Separate history stored in SharedPreferences
- Separate bookmarks
- JavaScript and DOM storage
- Search/address bar
- Back, forward, home and bookmark controls
- Incoming http/https links can open in Undrt Browser
- Responsive mobile-first dark UI with purple/cyan accents
- Simple popup menu for history/bookmarks

## Build

Open this folder in Android Studio and let Gradle sync.

Then use:
Build > Build APK(s)

The resulting APK is under:
app/build/outputs/apk/debug/

## Important

This uses Android WebView, not the Chrome app's private data. It therefore keeps Undrt's app-level history/bookmarks/cookies separate from Chrome.

WebView itself may receive system component updates independently of Chrome depending on the Android device configuration.
