package com.undrtbrowser

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var progress: ProgressBar
    private lateinit var title: TextView
    private val prefs by lazy { getSharedPreferences("undrt_data", MODE_PRIVATE) }

    private val bg = Color.rgb(11,16,32)
    private val surface = Color.rgb(21,27,48)
    private val surface2 = Color.rgb(28,36,64)
    private val accent = Color.rgb(124,92,255)
    private val cyan = Color.rgb(34,211,238)
    private val text = Color.rgb(247,248,255)
    private val muted = Color.rgb(167,176,204)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                view.loadUrl(request.url.toString())
                return true
            }
            override fun onPageFinished(view: WebView, url: String) {
                address.setText(url)
                title.text = view.title?.takeIf { it.isNotBlank() } ?: "Undrt Browser"
                saveHistory(view.title ?: url, url)
                progress.visibility = View.GONE
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }
        }

        val incoming = intent?.data
        if (incoming != null) web.loadUrl(incoming.toString())
        else web.loadUrl("https://www.google.com")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 8)
            setBackgroundColor(bg)
        }

        val brandRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "UNDЯT"
            textSize = 21f
            setTextColor(text)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        title = TextView(this).apply {
            text = "Undrt Browser"
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.END
        }
        brandRow.addView(brand, LinearLayout.LayoutParams(0, 44, 1f))
        brandRow.addView(title, LinearLayout.LayoutParams(0, 44, 1f))
        top.addView(brandRow)

        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 5, 8, 5)
            background = rounded(surface2, 28)
        }

        address = EditText(this).apply {
            hint = "Search or enter address"
            hintTextColor = muted
            setTextColor(text)
            textSize = 15f
            singleLine = true
            setPadding(12, 0, 8, 0)
            setBackgroundColor(Color.TRANSPARENT)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ ->
                navigate(text.toString()); true
            }
        }
        bar.addView(address, LinearLayout.LayoutParams(0, 50, 1f))

        val go = button("GO", accent) { navigate(address.text.toString()) }
        bar.addView(go, LinearLayout.LayoutParams(55, 42))

        top.addView(bar)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(cyan)
            visibility = View.GONE
        }
        top.addView(progress, LinearLayout.LayoutParams(-1, 3))

        web = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
        }
        root.addView(top, LinearLayout.LayoutParams(-1, 126))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(8, 7, 8, 7)
            setBackgroundColor(surface)
        }
        nav.addView(button("‹", surface2) { if (web.canGoBack()) web.goBack() })
        nav.addView(button("›", surface2) { if (web.canGoForward()) web.goForward() })
        nav.addView(button("⌂", surface2) { web.loadUrl("https://www.google.com") })
        nav.addView(button("★", surface2) { addBookmark() })
        nav.addView(button("☰", accent) { showMenu() })
        root.addView(nav, LinearLayout.LayoutParams(-1, 62))

        setContentView(root)
    }

    private fun button(label: String, color: Int, action: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(text)
            background = rounded(color, 18)
            setOnClickListener { action() }
            val p = LinearLayout.LayoutParams(0, 48, 1f)
            p.setMargins(4, 0, 4, 0)
            layoutParams = p
        }
    }

    private fun rounded(color: Int, radius: Float): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
        }

    private fun navigate(raw: String) {
        var q = raw.trim()
        if (q.isEmpty()) return
        if (!q.startsWith("http://") && !q.startsWith("https://")) {
            q = if (q.contains(".") && !q.contains(" ")) "https://$q"
            else "https://www.google.com/search?q=" + URLEncoder.encode(q, "UTF-8")
        }
        web.loadUrl(q)
    }

    private fun saveHistory(t: String, u: String) {
        val arr = JSONArray(prefs.getString("history", "[]"))
        val item = JSONObject().apply {
            put("title", t.ifBlank { u })
            put("url", u)
            put("time", System.currentTimeMillis())
        }
        val out = JSONArray().apply {
            put(item)
            for (i in 0 until minOf(arr.length(), 99)) put(arr.getJSONObject(i))
        }
        prefs.edit().putString("history", out.toString()).apply()
    }

    private fun addBookmark() {
        val arr = JSONArray(prefs.getString("bookmarks", "[]"))
        val item = JSONObject().apply {
            put("title", web.title ?: web.url)
            put("url", web.url)
        }
        for (i in 0 until arr.length())
            if (arr.getJSONObject(i).optString("url") == web.url) return
        arr.put(item)
        prefs.edit().putString("bookmarks", arr.toString()).apply()
        Toast.makeText(this, "Saved to Undrt bookmarks", Toast.LENGTH_SHORT).show()
    }

    private fun showMenu() {
        val popup = PopupWindow(this).apply {
            width = 300
            height = ViewGroup.LayoutParams.WRAP_CONTENT
            isFocusable = true
            elevation = 18f
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 14, 14, 14)
            background = rounded(surface, 22)
        }
        val history = menuItem("History") { showList("History", "history") }
        val bookmarks = menuItem("Bookmarks") { showList("Bookmarks", "bookmarks") }
        val clear = menuItem("Clear history") {
            prefs.edit().remove("history").apply()
            Toast.makeText(this, "Undrt history cleared", Toast.LENGTH_SHORT).show()
            popup.dismiss()
        }
        box.addView(history); box.addView(bookmarks); box.addView(clear)
        popup.contentView = box
        popup.showAtLocation(web, Gravity.TOP or Gravity.END, 14, 105)
    }

    private fun menuItem(label: String, action: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 16f
            setTextColor(text)
            setPadding(20, 18, 20, 18)
            setOnClickListener { action() }
        }

    private fun showList(header: String, key: String) {
        val arr = JSONArray(prefs.getString(key, "[]"))
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 18, 22, 18)
            setBackgroundColor(bg)
        }
        val h = TextView(this).apply {
            text = header
            textSize = 24f
            setTextColor(text)
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, 18)
        }
        box.addView(h)
        for (i in 0 until minOf(arr.length(), 50)) {
            val o = arr.getJSONObject(i)
            val row = TextView(this).apply {
                text = o.optString("title") + "\n" + o.optString("url")
                textSize = 14f
                setTextColor(text)
                setPadding(12, 14, 12, 14)
                background = rounded(surface, 14)
                setOnClickListener {
                    web.loadUrl(o.optString("url"))
                    (parent as? ViewGroup)?.removeView(this)
                }
            }
            val lp = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 0, 0, 8)
            box.addView(row, lp)
        }
        val scroll = ScrollView(this).apply { addView(box) }
        setContentView(scroll)
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
